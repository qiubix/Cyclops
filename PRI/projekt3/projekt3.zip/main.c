#include <stdio.h>
#include "funkcje.h"


int main()
{
powitanie();

exit(0);
}
