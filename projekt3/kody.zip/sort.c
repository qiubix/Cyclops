#include <stdio.h>
#include <string.h>
#include "def.h"
#include "funkcje.h"


extern struct element *poczatek;
extern struct element *koniec;


extern int N; /*zlicza wprowadzone przedmioty*/


void sort_nazwa()
{
     struct element *skoczek, *skoczek2, *aktualny;
	
	 skoczek = poczatek->nastepny;
	 while(skoczek!=NULL){
          aktualny = skoczek;
		  skoczek2 = skoczek->poprzedni;
		  skoczek = skoczek->nastepny;
		  while(strcmp(skoczek2->p.nazwa,aktualny->p.nazwa)<0&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		  if(strcmp(skoczek2->p.nazwa,aktualny->p.nazwa)<0) wstaw_przed(skoczek2,aktualny);
		  else
              if(strcmp(skoczek2->nastepny->p.nazwa,aktualny->p.nazwa)<0) wstaw_przed(skoczek2->nastepny,aktualny);
      /*printf("==== obieg ====\n");
      getchar();*/
		
	 }
     
     printf("Dane zostaly posortowane wedlug nazwy.\n");
     menu();
}

void sort_kod()
{
     struct element *skoczek, *skoczek2, *aktualny;
	
	 skoczek = poczatek->nastepny;
	 while(skoczek!=NULL){
          aktualny = skoczek;
		  skoczek2 = skoczek->poprzedni;
		  skoczek = skoczek->nastepny;
		  while(strcmp(skoczek2->p.kod,aktualny->p.kod)<0&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		  if(strcmp(skoczek2->p.kod,aktualny->p.kod)<0) wstaw_przed(skoczek2,aktualny);
		  else
              if(strcmp(skoczek2->nastepny->p.kod,aktualny->p.kod)<0) wstaw_przed(skoczek2->nastepny,aktualny);
      /*printf("==== obieg ====\n");
      getchar();*/
		
	 }
         
     
     printf("Dane zostaly posortowane wedlug kodu.\n");
     menu();
}


void sort_JD()
{
     struct element *skoczek, *skoczek2, *aktualny;
	
	 skoczek = poczatek->nastepny;
	 while(skoczek!=NULL){
          aktualny = skoczek;
		  skoczek2 = skoczek->poprzedni;
		  skoczek = skoczek->nastepny;
		  while((skoczek2->p.JD > aktualny->p.JD)&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		  if(skoczek2->p.JD > aktualny->p.JD) wstaw_przed(skoczek2,aktualny);
		  else
              if(skoczek2->nastepny->p.JD > aktualny->p.JD) wstaw_przed(skoczek2->nastepny,aktualny);
      /*printf("==== obieg ====\n");
      getchar();*/
		
	 }
     
     
     printf("Dane zostaly posortowane wedlug JD.\n");
     menu();
}


void sort_ECTS()
{
     struct element *skoczek, *skoczek2, *aktualny;
	
	 skoczek = poczatek->nastepny;
	 while(skoczek!=NULL){
          aktualny = skoczek;
		  skoczek2 = skoczek->poprzedni;
		  skoczek = skoczek->nastepny;
		  while((skoczek2->p.ECTS > aktualny->p.ECTS)&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		  if(skoczek2->p.ECTS > aktualny->p.ECTS) wstaw_przed(skoczek2,aktualny);
		  else
              if(skoczek2->nastepny->p.ECTS > aktualny->p.ECTS) wstaw_przed(skoczek2->nastepny,aktualny);
      /*printf("==== obieg ====\n");
      getchar();*/
		
	 }
     
     
     printf("Dane zostaly posortowane wedlug ECTS.\n");
     menu();
}


void sort_JK()
{
	struct element *skoczek, *skoczek2, *aktualny;
	
	skoczek = poczatek->nastepny;
	while(skoczek!=NULL){
		aktualny = skoczek;
		skoczek2 = skoczek->poprzedni;
		skoczek = skoczek->nastepny;
		while((skoczek2->p.JK > aktualny->p.JK)&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		if(skoczek2->p.JK > aktualny->p.JK) wstaw_przed(skoczek2,aktualny);
		else
            if(skoczek2->nastepny->p.JK > aktualny->p.JK) wstaw_przed(skoczek2->nastepny,aktualny);
        /*printf("==== obieg ====\n");
		getchar();*/
		
	}
	
	printf("Dane zostaly posortowane wedlug JK.\n");
    menu();
}





void sort_prowadzacy()
{
     struct element *skoczek, *skoczek2, *aktualny;
	
	 skoczek = poczatek->nastepny;
	 while(skoczek!=NULL){
          aktualny = skoczek;
		  skoczek2 = skoczek->poprzedni;
		  skoczek = skoczek->nastepny;
		  while(strcmp(skoczek2->p.prowadzacy,aktualny->p.prowadzacy)<0&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		  if(strcmp(skoczek2->p.prowadzacy,aktualny->p.prowadzacy)<0) wstaw_przed(skoczek2,aktualny);
		  else
              if(strcmp(skoczek2->nastepny->p.prowadzacy,aktualny->p.prowadzacy)<0) wstaw_przed(skoczek2->nastepny,aktualny);
      /*printf("==== obieg ====\n");
      getchar();*/
		
	 }
     
     printf("Dane zostaly posortowane wedlug prowadzacego.\n");
     menu();
}


void sort_klasa()
{
     struct element *skoczek, *skoczek2, *aktualny;
	
	 skoczek = poczatek->nastepny;
	 while(skoczek!=NULL){
          aktualny = skoczek;
		  skoczek2 = skoczek->poprzedni;
		  skoczek = skoczek->nastepny;
		  while(strcmp(skoczek2->p.prowadzacy,aktualny->p.prowadzacy)<0&&skoczek2->poprzedni != NULL) skoczek2=skoczek2->poprzedni;
		
		  if(strcmp(skoczek2->p.prowadzacy,aktualny->p.prowadzacy)<0) wstaw_przed(skoczek2,aktualny);
		  else
              if(strcmp(skoczek2->nastepny->p.prowadzacy,aktualny->p.prowadzacy)<0) wstaw_przed(skoczek2->nastepny,aktualny);
      /*printf("==== obieg ====\n");
      getchar();*/
		
	 }
     
     printf("Dane zostaly posortowane wedlug klasy.\n");
     menu();
}


void wstaw_przed(struct element *a, struct element *b)
{
	struct element *tmp;
	
	if(a->nastepny == b){
		if(a->poprzedni == NULL){
			if(b->nastepny == NULL){
				a->nastepny = NULL;
				a->poprzedni = b;
				b->nastepny = a;
				b->poprzedni = NULL;
				poczatek = b;
				printf("Opcja 1-1\n");
			}
			else{
				b->nastepny->poprzedni = a;
				b->poprzedni = NULL;
				a->nastepny = b->nastepny;
				b->nastepny = a;
				a->poprzedni = b;
				poczatek = b;
				printf("Opcja 1-2\n");
			}
		}
		else{
			if(b->nastepny == NULL){
				a->nastepny = NULL;
				a->poprzedni->nastepny = b;
				b->poprzedni = a->poprzedni;
				b->nastepny = a;
				a->poprzedni = b;
				printf("Opcja 1-3\n");
			}
			else{
				b->nastepny->poprzedni = a;
				a->poprzedni->nastepny = b;
				tmp = a->poprzedni;
				a->poprzedni = b;
				a->nastepny = b->nastepny;
				b->poprzedni = tmp;
				b->nastepny = a;
				printf("Opcja 1-4\n");
			}
		}
	}
	else{
		if(a->poprzedni == NULL){
			if(b->nastepny == NULL){
				b->poprzedni->nastepny = NULL;
				b->nastepny = a;
				b->poprzedni = NULL;
				a->poprzedni = b;
				poczatek = b;
				printf("Opcja 2-1\n");
			}
			else{
				b->poprzedni->nastepny = b->nastepny;
				b->nastepny->poprzedni = b->poprzedni;
				b->nastepny = a;
				b->poprzedni = NULL;
				a->poprzedni = b;
				poczatek = b;
				printf("Opcja 2-2\n");
			}
		}
		else{
			if(b->nastepny == NULL){
				b->poprzedni->nastepny = NULL;
				tmp = a->poprzedni;
				a->poprzedni->nastepny = b;
				b->nastepny = a;
				b->poprzedni = tmp;
				a->poprzedni = b;
				printf("Opcja 2-3\n");
			}
			else{
				b->poprzedni->nastepny = b->nastepny;
				b->nastepny->poprzedni = b->poprzedni;
				tmp = a->poprzedni;
				a->poprzedni->nastepny = b;
				a->poprzedni = b;
				b->nastepny = a;
				b->poprzedni = tmp;
				printf("Opcja 2-4\n");
			}
		}
	}
}




void zamien(struct element *a, struct element *b)
{
	struct element *tmp;
	
	if(a->nastepny == b){
		a->poprzedni->nastepny = b;
		b->nastepny->poprzedni = a;
		a->nastepny = b->nastepny;
		b->poprzedni = a->poprzedni;
		a->poprzedni = b;
		b->nastepny = a;
		
	}
	else{
		if(a->poprzedni == NULL){
			if(b->nastepny==NULL){
				b->poprzedni->nastepny = a;
				tmp = a->nastepny;
				a->nastepny = NULL;
				a->poprzedni = b->poprzedni;
				b->nastepny = tmp;
				b->poprzedni = NULL;
				poczatek = b;
				printf("opcja 1-2\n");
			
			}
			else{
				b->poprzedni->nastepny = a;
				b->nastepny->poprzedni = a;
				tmp = a->nastepny;
				a->nastepny = b->nastepny;
				a->poprzedni = b->poprzedni;
				b->nastepny = tmp;
				b->poprzedni = NULL;
				poczatek = b;
				printf("opcja 2\n");
			}
		}
		else{
			if(b->nastepny==NULL){
				a->poprzedni->nastepny = b;
				a->nastepny->poprzedni = b;
				tmp = b->poprzedni;
				b->poprzedni = a->poprzedni;
				b->nastepny = a->nastepny;
				a->poprzedni = tmp;
				a->nastepny = NULL;
				printf("opcja 3\n");
			}
			else{
				a->poprzedni->nastepny=b;
				a->nastepny->poprzedni=b;
				b->poprzedni->nastepny=a;
				b->nastepny->poprzedni=a;
				tmp=a->poprzedni;
				a->poprzedni=b->poprzedni;
				b->poprzedni=tmp;
				tmp=a->nastepny;
				a->nastepny=b->nastepny;
				b->nastepny=tmp;
				printf("opcja 4\n");
			}
		}
	}

}



