#include <stdio.h>
#include <stdlib.h>
#include "def.h"
#include "funkcje.h"

struct element *poczatek = NULL;
struct element *koniec;

int N; /*zlicza wprowadzone przedmioty*/

int main(int argc, char *argv[])
{
  powitanie();

  exit(0);
  
  system("PAUSE");	
  return 0;
}
