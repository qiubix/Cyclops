/*================prototypy funkcji==========================*/
void powitanie();
void menu();
void wczytaj_dane();
void buduj_liste(int );
int wpisz_przedmiot(struct przedmiot *);
int odczytaj_przedmiot(struct przedmiot *, FILE *);
void wczytaj_plik();
void edytuj();
void edytuj_jeden(struct element *);
void edytuj_caly(struct element **);
/*void edytuj_(struct element **);
void edytuj_(struct element **);
void edytuj_(struct element **);
void edytuj_(struct element **);
void edytuj_(struct element **);
void edytuj_(struct element **);
void edytuj_(struct element **);
void edytuj_(struct element **);*/
void usun();
void usun_jeden(struct element *);
void wypisz();
void menu_sort();
void zapisz();
void zakoncz();
void sort_nazwa();
void sort_kod();
void sort_JD();
void sort_ECTS();
void sort_JK();
void sort_prowadzacy();
void sort_klasa();
void sort_liczby();
void sort_znaki();
void sortuj_liczby();
void zamien(struct element * , struct element * );
void wstaw_przed(struct element *, struct element *);

